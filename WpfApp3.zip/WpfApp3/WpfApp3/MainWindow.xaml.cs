﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Microsoft.Win32;

namespace WupSoftware
{
    public partial class MainWindow : Window
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

        [DllImport("kernel32.dll")]
        static extern IntPtr CreateRemoteThread(IntPtr hProcess, IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

        const int PROCESS_CREATE_THREAD = 0x0002;
        const int PROCESS_QUERY_INFORMATION = 0x0400;
        const int PROCESS_VM_OPERATION = 0x0008;
        const int PROCESS_VM_WRITE = 0x0020;
        const int PROCESS_VM_READ = 0x0010;
        const uint MEM_COMMIT = 0x00001000;
        const uint MEM_RESERVE = 0x00002000;
        const uint PAGE_READWRITE = 4;

        private DispatcherTimer timer;
        private double progress = 0;
        private string dllPath = "";

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            var fadeIn = (Storyboard)FindResource("SplashFadeIn");
            fadeIn.Begin();

            var snowFall = (Storyboard)FindResource("SnowFall");
            snowFall.Begin();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(40);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            progress += 1;
            LoadingBarFill.Width = (ActualWidth - 120) * (progress / 100);

            if (progress >= 100)
            {
                timer.Stop();
                LoadingText.Text = "Hazır!";

                var fadeOut = (Storyboard)FindResource("SplashFadeOut");
                fadeOut.Completed += (s, a) =>
                {
                    SplashScreen.Visibility = Visibility.Collapsed;
                    MainContent.Visibility = Visibility.Visible;
                    var mainFadeIn = (Storyboard)FindResource("MainContentFadeIn");
                    mainFadeIn.Begin();
                };
                fadeOut.Begin();
            }
        }

        private void TitleBar_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void AboutButton_Click(object sender, RoutedEventArgs e)
        {
            AboutPopup.Visibility = Visibility.Visible;
        }

        private void CloseAbout_Click(object sender, RoutedEventArgs e)
        {
            AboutPopup.Visibility = Visibility.Collapsed;
        }

        private void SourceCode_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start("https://github.com/n0wzy8/Wup--njector");
            }
            catch
            {
                AppendConsole("✗ Tarayıcı açılamadı!");
            }
        }

        private void BrowseDll_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "DLL Files (*.dll)|*.dll|All Files (*.*)|*.*";
            openFileDialog.Title = "DLL Dosyası Seçin";

            if (openFileDialog.ShowDialog() == true)
            {
                dllPath = openFileDialog.FileName;
                DllPathTextBox.Text = dllPath;
                AppendConsole($"✓ DLL seçildi: {Path.GetFileName(dllPath)}");
            }
        }

        private void Inject_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(dllPath))
            {
                AppendConsole("✗ HATA: DLL dosyası seçin!");
                MessageBox.Show("Lütfen DLL dosyası seçin!", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!int.TryParse(PidTextBox.Text, out int pid))
            {
                AppendConsole("✗ HATA: Geçersiz PID!");
                MessageBox.Show("Geçerli PID girin!", "Uyarı", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                AppendConsole($"➤ Process açılıyor (PID: {pid})...");
                IntPtr hProcess = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, false, pid);

                if (hProcess == IntPtr.Zero)
                {
                    AppendConsole("✗ Process açılamadı!");
                    MessageBox.Show("Yönetici olarak çalıştırın!", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                AppendConsole("➤ LoadLibrary adresi alınıyor...");
                IntPtr loadLibraryAddr = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA");

                AppendConsole("➤ Bellek ayrılıyor...");
                IntPtr allocMemAddress = VirtualAllocEx(hProcess, IntPtr.Zero, (uint)((dllPath.Length + 1) * Marshal.SizeOf(typeof(char))), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

                AppendConsole("➤ DLL yolu yazılıyor...");
                WriteProcessMemory(hProcess, allocMemAddress, Encoding.Default.GetBytes(dllPath), (uint)((dllPath.Length + 1) * Marshal.SizeOf(typeof(char))), out UIntPtr bytesWritten);

                AppendConsole("➤ Thread oluşturuluyor...");
                CreateRemoteThread(hProcess, IntPtr.Zero, 0, loadLibraryAddr, allocMemAddress, 0, IntPtr.Zero);

                AppendConsole("══════════════════════════");
                AppendConsole("✓ INJECT BAŞARILI!");
                AppendConsole("══════════════════════════");

                MessageBox.Show("DLL inject edildi!", "Başarılı", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                AppendConsole($"✗ HATA: {ex.Message}");
                MessageBox.Show($"Hata: {ex.Message}", "Hata", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AppendConsole(string message)
        {
            string timestamp = DateTime.Now.ToString("HH:mm:ss");
            ConsoleOutput.Text += $"\n[{timestamp}] {message}";
        }
    }
}